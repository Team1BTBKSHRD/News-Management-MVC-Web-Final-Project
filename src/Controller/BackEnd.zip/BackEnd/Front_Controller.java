package Controller.BackEnd;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
//import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import Controller.BackEnd.Category.*;
import Controller.BackEnd.User.*;
import Controller.BackEnd.UserInfo.*;
import Controller.Filter.*;

//import Model.userDAO;

@WebServlet("*.news")
public class Front_Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public Front_Controller() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doProcess(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doProcess(request, response);

	}

	protected void doProcess(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String RequestURI = request.getRequestURI();
		String contextPath = request.getContextPath();		
		String command = RequestURI.substring(contextPath.length());
		ActionForward forward = null;
		Action action = null;
		
		System.out.println(RequestURI);
		System.out.println(contextPath);
		System.out.println("--" + command);
		
		switch (command) {
		// access to user url
		case "/Admin/useradd.news":
			action = new AddUser();
			try {
				action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
		case "/Admin/usertypelist.news":
			action = new ListUser();
			try {
				action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
		// access to userinfo url
		case "/Admin/userinfolist.news":
			action = new ListUserInfo();
			try {
				action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
		case "/userinfoedit.news":
			action = new EditUserInfo();
			try {
				action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
		// access to category url
		case "/Admin/pg_cate_tblistcategory.news":

			action = new ListCategory();
			try {
				action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;		
		/* End Case : Category Insert */
		case "/Admin/categoryDropList.news":

			action = new dropListCategory();
			try {
				action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
		case "/Admin/sourceDropList.news":
			action = new dropListSource();
			try {
				action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
			/*for update status sarin*/
		case "/Admin/updateStatus.news":
			action = new updateStatus();
			try {
				action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;	
		case "/Admin/selectTypeArticles.news":
			action = new typeofarticlespost();
			try {
				action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
		case "/Login/Login.news":

			action = new Login();

			System.out.println("He");
			try {
				System.out.println("in try");
				action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
		/*
		 * case "/getUcategoryDropListserInfoName.news":
		 * //System.out.println("getUserInfoName111"); action = new
		 * returnUserInfoName(); try { action.execute(request, response); }
		 * catch (Exception e) { e.printStackTrace(); } break; case
		 * "/listpopular.news": action = new ListPopular(); try {
		 * action.execute(request, response); } catch (Exception e) {
		 * e.printStackTrace(); }
		 */
		/* File Upload */
		case "/Admin/UploadServlet.news":
			action = new FileUpload();
			System.out.println("-------Upload Photo------");
			try {
				action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
		/*############################deprecated controller*/
	/*	case "/listexchange.news":
			action = new listexchange();
			try {
				action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
		case "/joblist.news":
			action = new listjobs();
			try {
				action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;		  
		case "/listallnews.news":
			action = new ListAllNews();
			try {
				action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;		  
		case "/recentnews.news":
			action = new ListRecentNews();
			try {
				action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
		case "/countview.news":
			action = new countView();
			try {
				action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;*/
			
		/*###################################################*/
		/*################################################other controller are not sure*/
/*			// Article Control news
			case "/newsarticleadd.news":

				action = new AddNews();
				try {
					action.execute(request, response);
				} catch (Exception e) {
					e.printStackTrace();
				}
				break;
			case "/Admin/listarticle.news":

				action = new ListNews();
				try {
					action.execute(request, response);
				} catch (Exception e) {
					e.printStackTrace();
				}
				break;
			case "/Admin/counts.news":
				action = new countNews();
				try {
					action.execute(request, response);
				} catch (Exception e) {
					e.printStackTrace();
				}
				break;
			//Add Article 
			case "/Admin/addarticle.news":
				action = new AddNews();
				System.out.println("/Admin/addarticle.news");
				try {
					System.out.println("------Add-------");
					action.execute(request, response);
				} catch (Exception e) {
					e.printStackTrace();
				}
				
				break;
			//mi kBo New Case
			case "/category.news":
				action = new ListNewsByCategoryCode();
				System.out.println("-------List New Category By Cat Code------");
				try {
					action.execute(request, response);
				} catch (Exception e) {
					e.printStackTrace();
				}
				break;*/
		/*#########################################################################*/
		default:
			forward = new ActionForward();
			forward.setPath("404.jsp");
			forward.setRedirect(true);
			break;
		}// End of switch;
		if (forward != null) {
			if (forward.isRedirect()) {
				response.sendRedirect(forward.getPath());
			} else {
				RequestDispatcher dispatcher = request.getRequestDispatcher(forward.getPath());
				dispatcher.forward(request, response);
			}

		}
	}
}
